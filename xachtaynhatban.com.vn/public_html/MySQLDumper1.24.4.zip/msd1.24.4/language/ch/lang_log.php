<?php
$lang['L_LOG_DELETE']="Log lösche";
$lang['L_LOGFILEFORMAT']="Log-Dateiformat";
$lang['L_LOGFILENOTWRITABLE']="Log-Datei cha nöd gschribe wärde!";
$lang['L_NOREVERSE']="ältischte Iitrag zerscht";
$lang['L_REVERSE']="neuschte Iitrag zerscht";


?>