<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Hasta el momento, se han recuperado <b>%d</b> tablas.";
$lang['L_FILE_MISSING']="no se encuentra el fichero";
$lang['L_RESTORE_DB']="la base de datos '<b>%s</b>' en '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> Las tablas han sido importadas.";
$lang['L_RESTORE_RUN1']="<br>Hasta ahora se han importado <b>%s</b> de <b>%s</b> registros";
$lang['L_RESTORE_RUN2']="<br/>Se está llenando de datos la tabla '<b>%s</b>'.<br/><br/>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> registros insertados.";
$lang['L_RESTORE_TABLES_COMPLETED']="Hasta el momento, se han recuperado <b>%d</b> de <b>%d</b> tablas.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Felicidades.</b><br><br>La base de datos ha sido completamente restaurada.<br>Todos los datos de la copia de seguridad han sido importados con éxito.<br><br>He terminado. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Error:<br>La selección de la base de datos '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' ha fallado!";
$lang['L_FILE_OPEN_ERROR']="Error: no he podido abrir el fichero.";
$lang['L_PROGRESS_OVER_ALL']="Progreso total";
$lang['L_BACK_TO_OVERVIEW']="vista de base de datos";
$lang['L_RESTORE_RUN0']="Hasta el momento, se han recuperado <b>%s</b> de tablas.";
$lang['L_UNKNOWN_SQLCOMMAND']="comando SQL desconocido";
$lang['L_NOTICES']="Avisos";


?>