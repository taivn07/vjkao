<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Até agora <b>%d</b> tabelas foram criadas.";
$lang['L_FILE_MISSING']="não pude encontrar o arquivo";
$lang['L_RESTORE_DB']="banco de dados '<b>%s</b>' em '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tabelas driadas.";
$lang['L_RESTORE_RUN1']="<br>Up to now  <b>%s</b> of <b>%s</b> registros foram adicionados com sucesso.";
$lang['L_RESTORE_RUN2']="<br>Agora a tabela '<b>%s</b>' está sendo restaurada.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> registros inseridos.";
$lang['L_RESTORE_TABLES_COMPLETED']="Até agora <b>%d</b> de <b>%d</b> tabelas foram criadas.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Parabéns.</b><br><br>A restauração do banco de dados está pronta.<br>todos os dados do arquivo de backup foram restaurados.<br><br>Está tudo pronto. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Error:<br>Seleção do banco de dados <b>";
$lang['L_DB_SELECT_ERROR2']="</b> falhou!";
$lang['L_FILE_OPEN_ERROR']="Erro: não pude abrir o arquivo.";
$lang['L_PROGRESS_OVER_ALL']="Progresso do todo";
$lang['L_BACK_TO_OVERVIEW']="Visão geral do banco de dados";
$lang['L_RESTORE_RUN0']="<br>até agora <b>%s</b> registros foram adicionados com sucesso.";
$lang['L_UNKNOWN_SQLCOMMAND']="comando SQL desconhecido";
$lang['L_NOTICES']="Notices";


?>