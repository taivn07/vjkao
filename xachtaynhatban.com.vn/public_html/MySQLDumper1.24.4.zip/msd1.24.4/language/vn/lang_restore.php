<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Cho tới giờ, <b>%d</b> bảng đã được tạo ra.";
$lang['L_FILE_MISSING']="không tìm thấy file";
$lang['L_RESTORE_DB']="'<b>%s</b>' CSDL trong '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> bảng đã được tạo ra.";
$lang['L_RESTORE_RUN1']="<br>Tính đến giờ, <b>%s</b> trong số <b>%s</b> bản ghi đã được thêm vào thành công.";
$lang['L_RESTORE_RUN2']="<br>Hiện tại bảng '<b>%s</b>' đang được phục hồi.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> bản ghi được chèn vào.";
$lang['L_RESTORE_TABLES_COMPLETED']="Tính đến giờ, <b>%d</b> trong số <b>%d</b> table đã được tạo.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Chúc mừng.</b><br><br>Việc phục hồi cơ sở dữ liệu đã xong.<br>Tất cả dữ liệu Sao lưu đã được phục hồi.<br><br>Mọi việc đã kết thúc. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Lỗi:<br>Lựa chọn CSDL <b>";
$lang['L_DB_SELECT_ERROR2']="</b> thất bại!";
$lang['L_FILE_OPEN_ERROR']="Lỗi: Không thể mở file.";
$lang['L_PROGRESS_OVER_ALL']="Toàn bộ tiến trình";
$lang['L_BACK_TO_OVERVIEW']="Tổng quan Cơ sở dữ liệu";
$lang['L_RESTORE_RUN0']="<br>Tính đến giờ, <b>%s</b> bản ghi đã được thêm vào thành công.";
$lang['L_UNKNOWN_SQLCOMMAND']="không hiểu lệnh SQL";
$lang['L_NOTICES']="Chú ý


";


?>