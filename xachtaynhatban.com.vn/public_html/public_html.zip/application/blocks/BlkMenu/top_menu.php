<div class="block_topMenu">
	<?php echo $view->blkUser();?>
	<?php echo $strMenu;?>
	<div class="clr"></div>
</div>