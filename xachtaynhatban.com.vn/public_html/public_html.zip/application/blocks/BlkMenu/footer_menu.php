<div class="block_footerMenu">
	<div id="footerMenu" class="footerMenu">
       	<?php echo $strMenu;?>
	</div>
	<script type="text/javascript">
		$('.goTop').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	</script>
</div>