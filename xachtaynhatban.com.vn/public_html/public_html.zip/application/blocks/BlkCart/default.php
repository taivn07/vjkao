<div class="block_cart">
	<div class="block_title">
		<div class="title"><?php echo $view->language['productGioHang'];?></div>
	</div>
	<div id="danhsach_giohang" class="block_content">
		
	</div>
</div>