<div class="block_footer">
    <div class="block_content">
	    <?php echo $view->blkHtml('default',2);?>
    </div>
</div>
<a href="javascript:void(0)" title="Go top" rel="nofollow" class="goTop">&nbsp;</a>
