<div class="block_thongKe">
	<div class="block_title">
		<div class="title"><?php echo $view->language['thongKe']?></div>
	</div>
	<div class="block_content">
		<?php echo $counter;?>
	</div>
</div>