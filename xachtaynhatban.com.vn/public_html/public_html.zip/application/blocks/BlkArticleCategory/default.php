<div class="block_leftMenu">
	<div class="block_title">
		<span class="icon"></span>
		<h4><?php echo $view->language['danhMuc'];?></h4>
	</div>
	<div class="block_content">
		<div>
			<?php echo $strMenu;?>
		</div>
	</div>
</div>