<?php
	$siteConfig = Zend_Registry::get('siteConfig');
?>
<div class="block_header">
	<?php echo $view->blkHtml('default', 1);?>
</div>