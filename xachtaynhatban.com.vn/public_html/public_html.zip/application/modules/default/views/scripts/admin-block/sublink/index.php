<?php

	$linkBlock = '';
	
?>
<div id="submenu-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m">
		<ul id="submenu">
			<li><a href="<?php echo $linkBlock;?>" class="active">Quản lý Blocks</a></li>
		</ul>
		<div class="clr"></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>