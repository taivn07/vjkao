<?php
	$linkSiteSettings =  $this->baseUrl('/default/admin-user/index/');
?>
<div class="block_subMenu goc10">
	<ul>
		<li><a href="#" class="active">Cấu hình hệ thống</a></li>
	</ul>
	<div class="clr"></div>
</div>