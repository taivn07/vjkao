<?php
	$strBtn = '';
	//Icon toolbar
	$IconToolbar = 'icon-48-mediamanager';
?>
<div class="block_toolbar goc10">
	<div class="toolbar">
		<?php echo $strBtn;?>
		<div class="clr"></div>
	</div>
	<div class="header <?php echo $IconToolbar;?>"><?php echo $this->Title;?></div>
	<div class="clr"></div>
</div>