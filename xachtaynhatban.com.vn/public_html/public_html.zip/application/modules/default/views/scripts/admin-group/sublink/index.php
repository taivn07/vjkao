<?php
	$linkMemberManager =  $this->baseUrl('/default/admin-user/index');
	$linkPermission =  $this->baseUrl('/default/admin-permission/index');
	$linkPermission =  $this->baseUrl('/default/admin-permission/index');
?>
<div class="block_subMenu goc10">
	<ul>
		<li><a href="#" class="active">Nhóm thành viên</a></li>
		<li><a href="<?php echo $linkMemberManager;?>">Thành viên</a></li>
		<li><a href="<?php echo $linkPermission;?>">Quyền thành viên</a></li>
	</ul>
	<div class="clr"></div>
</div>