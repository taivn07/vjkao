<?php
	/* $linkArticleCategory =  $this->baseUrl('/article/admin-category/index/');
	$linkArticle =  $this->baseUrl('/article/admin-item/index/');
	$linkComment =  $this->baseUrl('/article/admin-comment/index/'); */
?>
<div class="block_subMenu goc10">
	<ul>
		<li><a href="#" class="active">Danh sách liên hệ</a></li>
	</ul>
	<div class="clr"></div>
</div>