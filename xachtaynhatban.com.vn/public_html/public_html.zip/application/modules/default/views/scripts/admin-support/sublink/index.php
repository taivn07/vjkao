<?php
	/* $linkCategory =  $this->baseUrl('/hotel/admin-category/index/');
	$linkHotel =  $this->baseUrl('/hotel/admin-item/index/');
	$linkComment =  $this->baseUrl('/hotel/admin-comment/index/'); */
?>
<div class="block_subMenu goc10">
	<ul>
		<li><a href="#" class="active">Danh sách</a></li>
	</ul>
	<div class="clr"></div>
</div>